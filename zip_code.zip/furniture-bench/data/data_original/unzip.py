import os
import zipfile
import shutil

source_folder = 'lamp_zip'
destination_folder = 'data_task_lamp'

# Create the destination folder if it does not exist
os.makedirs(destination_folder, exist_ok=True)

# Loop through all the files in the original_data folder
for filename in os.listdir(source_folder):
    if filename.endswith('.zip'):
        zip_path = os.path.join(source_folder, filename)
        
        # Open the zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Extract only the .pkl files from the 'lamp' folder
            for file_info in zip_ref.infolist():
                if file_info.filename.startswith('lamp/') and file_info.filename.endswith('.pkl'):
                    # Define the path to extract the file to
                    destination_file_path = os.path.join(destination_folder, os.path.basename(file_info.filename))
                    
                    # Extract the .pkl file
                    with zip_ref.open(file_info.filename) as source, open(destination_file_path, 'wb') as target:
                        shutil.copyfileobj(source, target)

print("Extraction complete.")