from enum import Enum


class KeyEnum(Enum):
    FALSE = 2
    SUCCESS = 3
    FAIL = 4
    REWARD = 5
