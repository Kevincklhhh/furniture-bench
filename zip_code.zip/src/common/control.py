class RotationMode:
    quat = "quat"
    rot_6d = "rot_6d"


class ControlMode:
    position = "pos"
    delta = "delta"
